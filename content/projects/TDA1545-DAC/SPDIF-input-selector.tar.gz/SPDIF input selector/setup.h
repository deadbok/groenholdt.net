#ifndef SETUP_H
#define SETUP_H

#define PIC_CLK 4000000

#endif	SETUP_H
