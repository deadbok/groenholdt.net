#include <pic.h>
#include "lcd.h"
#include "delay.h"

/**
 * HD44780 LCD handling routines
 * \file lcd.c
 * \author Martin Bo Kristensen Gr�nholdt
 */

/** Define which pin is connected to the RS pin of the LCD
 */
#define	LCD_RS RC3
/** Define which pin is connected to the RW pin of the LCD
 */
#define	LCD_RW RC4
/** Define which pin is connected to the EN pin of the LCD
 */
#define LCD_EN RC5

/** Define which ports lower 4 bits are connected to the high 4 bits data pins (D4-D7) on the LCD
 */
#define LCD_DATA	PORTB

/** Pulse the EN line, after sending to the LCD controller
 */
#define	LCD_STROBE()	((LCD_EN = 1),(LCD_EN=0))

/** The number of lines on the display
 */
#define LCD_HEIGHT 4

/** The number of characters on a line
 */
#define LCD_WIDTH 20

/** Lookup table for the address of each line in the display
 */
 bank1 unsigned char	line_table[4] = { 0x00,0x40,0x14,0x54 };
/** Variables to keep track of the the current horizontal position of the cursor
 */
 bank1 unsigned char	x = 0;
/** Variables to keep track of the the current vertical position of the cursor
 */
 bank1 unsigned char	y = 0;
void lcd_goto(unsigned char x, unsigned char y);

/** Write a byte to the LCD in 4 bit mode
 *	\param c	Byte to write*/
void lcd_write(unsigned char c)
{
	//Send the high 4 bits of the data
	LCD_DATA = ( ( c >> 4 ) & 0x0F ) | (LCD_DATA & 0xF0);
	//Wait for a while instead of polling
	DelayUs(250);
	//Pulse the EN line of the display
	LCD_STROBE();
	//Send the low 4 bits of the data
	LCD_DATA = ( c & 0x0F ) | (LCD_DATA & 0xF0);
	//Wait for a while instead of polling
	DelayUs(250);
	//Pulse the EN line of the display
	LCD_STROBE();
}

/**	Clear and home the LCD
 */
void lcd_clear(void)
{
	//Command mode
	LCD_RS = 0;
	//Send "Clear display"
	lcd_write(0x1);
	//Wait for the LCD instead of polling
	DelayMs(2);
	//Move to first line
	x = y = 0;
}

/** Home the cursor wiyhout clearin the screen (faster).
 */
void lcd_home(void)
{
	lcd_goto(0,0);
	
	x = y = 0;
}	

/** Write a string of chars to the LCD
 *	\param s	Pointer to the string to write
 */
void puts(const char *s)
{
	//Write the characters to the LCD
	while(*s)
		putch(*s++);
}

/** Write one character to the LCD
 *	\param	c	Character to write
 */
void putch(char c)
{
	//Data mode
	LCD_RS = 1;

	//New line
	if (c == '\n')
	{
		//If this is not the last line
		if (y < LCD_HEIGHT)
			y++;
		
		x = 0;
		
		//Go to next line
		lcd_goto(0, y);
	}
	else
	{
		//Write the character to the LCD
		lcd_write( c );
		//Increase position counter
		x++;
		//Check if the line has ended
		if ((x - line_table[y]) > 20)
		{
			y++;
			x = 0;
		}
	}
}


/** Set the cursor to the specified position. (0.0) is the the upper
 *	left corner.
 *	\param	x	Horizontal position
 *	\param	y	Vertical position
 */
void lcd_goto(unsigned char x, unsigned char y)
{
	//Command mode
	LCD_RS = 0;
	//Send "Set DDRAM" + new position
	lcd_write(0x80+x + line_table[y]);
}

/** Enabled or disabled the display of the cursor	
 *	\param	enabled	
 					- 1 enables the cursor
 *					- 0 disables the cursor
 */
void lcd_cursor(unsigned char enabled)
{
	//"Display on/off control", display on, cursor off, blinking off
	unsigned char	cmd = 0b00001100;
	//Command mode
	LCD_RS = 0;
	
	//Chose the right command
	if (enabled)
	//"Display on/off control", display on, cursor on, blinking on
		enabled = 0b00001111;
		
	//Send the command
	lcd_write(cmd);
}
	

/** Initialise the LCD - put into 4 bit mode
 */
void lcd_init(void)
{	
	//Wait 15mS after power applied
	DelayMs(15);

	//Set the pins according to the datasheet
	LCD_RS = 0;
	LCD_EN = 0;
	LCD_RW = 0;

	//Send "Function set", 3 times
	LCD_DATA = 0x03 | (LCD_DATA & 0xF0); 
	LCD_STROBE();
	DelayMs(5);
	LCD_STROBE();
	DelayMs(1);
	LCD_STROBE();
	DelayMs(1);
	
	//Set 4-bit mode
	LCD_DATA = 2 | (LCD_DATA & 0xF0);
	LCD_STROBE();

 	//Set interface length
	lcd_write(0x28);
	//Display On, Cursor On, Cursor Blink
	lcd_write(0xF);
	//Clear screen 
	lcd_clear();
	//Set entry Mode
	lcd_write(0x6);
}

/** This function prints the spaces needed to adjust a number to a fixed position
 *	Since the HI-Tech C library printf function does not seem to properly support
 * 	%m.n conversion specification, This function is used pad with the correct amount
 *	of characters
 *	\param	precision	The width the final value should fill
 *	\param	value		The value to pad
 *	\param	ch			The character to be used as padding
 */
void pad(unsigned char precision, unsigned long value, unsigned char ch)
{
	//Just a counter variable
	unsigned long	i = precision;
	//The powers of ten
	unsigned long	tenth = 1;
	
	//Calculate the maximum power of ten
	while (i > 1)
	{
		tenth *= 10;
		i--;
	}
	
	//Divide by each power of ten
	for ( i = precision; i > 1; i--)
	{
		//If there is no value, print a space
		if ((value / tenth) == 0)
		{
			putch(ch);
		}
			
		//Next power of ten
		tenth /= 10;
	}
}
