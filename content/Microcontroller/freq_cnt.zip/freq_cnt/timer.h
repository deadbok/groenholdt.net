#ifndef TIMER_H
#define TIMER_H

/**
 * Include file for the timer handling routines
 * \file timer.h
 * \author Martin Bo Kristensen Gr�nholdt
 */
 
extern void init_TMR0(void);
extern void init_TMR1(void);

#endif
