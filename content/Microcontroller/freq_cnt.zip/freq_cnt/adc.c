#include <pic.h>
#include "adc.h"

/** Contain the ADC handling routines
 * 	\file adc.c
 * 	\author Martin Bo Kristensen Gr�nholdt
 */

/** This function initializes the ADC in the following way:
 *		- A/D Conversion clock to clock / 32 = 1,6us
 *		- All channels are A/D input channels with intenal reference
 *		- Output is right justified in ADRESH:ADRESHL
 *		- Channel 0 is selected
 *		- The A/D converter is enabled
 *
 *	The A/D is used to measure the voltage of the signal
 */
void init_ADC(void)
{
	//Conversion clock = Clock speed/32
#ifdef _16F876A
	ADCS2 = 0;		//Only the "A" version have this register
#endif
	ADCS1 = 1;
	ADCS0 = 0;

	//Select CH0
	CHS2 = 0;
	CHS1 = 0;
	CHS0 = 0;

	//Right justified
 	ADFM = 1;

	//All analog inputs
	//Internal voltage references
	PCFG3 = 0;
	PCFG2 = 0;
	PCFG1 = 0;
	PCFG0 = 0;

	//Enable the ADC
	ADON = 1;
}

