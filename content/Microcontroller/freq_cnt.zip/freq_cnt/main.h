#ifndef	MAIN_H
#define	MAIN_H

/**
 * Include file for the main program routines
 * \file main.h
 * \author Martin Bo Kristensen Gr�nholdt
 */

extern unsigned long	time;
extern unsigned int		TMR1HH;

#endif


