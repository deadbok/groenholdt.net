#include <pic.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "main.h"
#include "lcd.h"
#include "delay.h"
#include "timer.h"
#include "adc.h"
#include "fixed.h"

/** Contain the main program routines
 * 	\file main.c
 * 	\author Martin Bo Kristensen Gr�nholdt
 */
 
/** \mainpage PICMicro frequency counter
 *	\section Introduction
 *	This is the code documentation of a frequency counter build around a PIC16F876
 *	a HD44870 compatible LCD, and an external amplifier.
 *	\author Martin Bo Kristensen Gr�nholdt
 *	\version 1.0
 *		First working version
 *	\version 1.10
 *		Added voltage calibration
 *	\version 1.13
 *		Split main.c into more files.\n
 *		Faster LCD output.\n
 *		Better LCD position handling.
 *	\version 1.20
 *		Shiny new counting algorithm\n
 *		The signal is turned on and of externaly by a 
 *		transistor. This is easier to time, and simplifies
 *		the code.
 *	\version 1.21
 *		Voltage calculations now use 16.16 fixed point math
 */

/* 	Highspeed clock
 *	Brown Out disable
 *	Low Voltage programming disabled
 *	No code protection
 *	Watchdog timer disabled
 */
__CONFIG(HS & BORDIS & LVPDIS & DUNPROT & WDTDIS);

/** Disable shunting TMR1 input to ground, e.g. enable pulse count
 */
#define	COUNT_ON()	(RB5 = 0)
/** Enable shunting TMR1 input to ground, e.g. disable pulse count
 */
#define	COUNT_OFF()	(RB5 = 1)

/** The squareroot of 2 representet as 16.16 fixed point, to calculate
 *	RMS value
 */
#define SQRT2		92682

/**	Stores the number of pulses (frequency) read from timer 1
 */
bank1 unsigned long	freq;

/**	Overflow from timer 0
 */
unsigned long	time;

/** Used to divide the measure time for faster readings
 *	at higher frequencies
 */
bank1 unsigned int	divisor = 1;

/** Description:	Overflow from timer 1
 */
unsigned int	TMR1HH;

/** The minimum voltage measured during last cycle
 */
bank1 fixed			vin_min = ULONG_MAX;

/** The maximum voltage measured during last cycle
 */
bank1 fixed			vin_max = 0;

/** The calibrated value for converting A/D readings into voltage units
 *	\note This value is stored in EEPROM
 */
//eeprom fixed	vin_cal = 13369344; //204.80 using 16.16 fixed point;
fixed			vin_cal = 13369344; //204.80 using 16.16 fixed point;


/** This function initializes the interruptsystem in the following way:
 *		- Timer 0 overflow interrupt enabled
 *		- Peripheral interrupts enabled
 *		- Timer 1 overlfow interrupt enabled
 *		- Global interrupt enable
 */
void init_int(void)
{
	//Timer 0 overflow interrupt enabled
	T0IE = 1;
	//Peripheral interrupts enabled
	PEIE = 1;
	//Timer 1 overflow interrupt enabled
	TMR1IE = 1;
	//Global interrupt enable
	GIE = 1;
}

/**	This function  is the interrupt service routine
 *	It takes care of a number of things
 *		- Increase the timer 0 overflow variable (#time) everytime an overflow has occured
 *		- Increase the timer 1 overflow variable (#TMR1HH) everytime an overflow occured
 *
 * 	\note This is the interrupt handler
 */
void interrupt ISR(void)
{
	//Overflow happens every 1.6us * 255-130 = 200us 
	if (T0IF)
	{
		//3 must be the instructions leading here and the
		//delay of 3 instruction cycles when writing timer 0
		TMR0 = 133;
		//Increase the high portion of the counter
		time++;
		//Reset the interrupt flag
		T0IF = 0;
	}
	//Overflow happens when enough (2^16) pulses are recieved
	if (TMR1IF)
	{
		//Increase the high portion of the counter
		TMR1HH++;
		//Reset the interrrupt flag
		TMR1IF = 0;
	}
}

/**	This function is the main meaurement cycle
 *	The number of pulses is counted using timer 1 and stored in #freq. The period of the count is \a ms
 *	counted using timer 0 with every 625 counts being a milisecond. While counting repeated measuremens
 *	are taken using channel 0 of the A/D and the minumum and maximum values are stored in #vin_min and 
 *	#vin_max.\n
 *	Since timer 1 has a prescaler of 1:2 it takes two seconds to measure 1Hz.
 *
 * 	\param 	ms	Number of miliseconds the measurements are run
 */
void measure(unsigned int ms)
{
	//Convert the wait time from miliseconds to timer 0 ticks. 5 * 200us = 1ms
	unsigned long	wait_time	= (5 * (unsigned long)(ms);
	//Temporary storage for the ADC sample
	unsigned int	voltage;

	//Reset timer 1, who keeps track of the pulses
	TMR1HH = TMR1H = TMR1L = 0;

	//When is it time to stop?
	wait_time += time;
	
	//Turn on counting
	COUNT_ON();
	
	//Start measuring until timer 0 reaches waitTime ticks
	while (time < wait_time)
	{
		//Start sampling from channel 0
		ADGO = 1;
		
		//Wait til sampling is done
		while (ADGO)
		{}

		//Save the measurement
		voltage = ((unsigned int)(ADRESH) << 8) + (unsigned char)(ADRESL);
		
		ADIF  = 0;

		//If the voltage is the lowest yet, save it
		if (voltage < vin_min.split.integer)
			vin_min.split.integer = voltage;
		//If the voltage is the highest yet, save it
		if (voltage > vin_max.split.integer)
			vin_max.split.integer = voltage;

		//Make sure the ADC is ready for another go
		//It neeeds TAD * 11.5 for each 10 bit conversion
		//1.6us * 11.5 = 18.4us
		DelayUs(18);
	}
	
	//Turn off counting
	COUNT_OFF();

	//Save the counted pulses in freq
	freq = ((((unsigned long)(TMR1H) << 8 ) + (unsigned long)(TMR1L)) + ((unsigned long)(TMR1HH) << 16));
}

unsigned long freq_fraction(void)
{
	unsigned long freq_full;
	
	freq_full = freq * divisor;
	
	freq_full %= 1000;
		
	return( freq_full );
}	
		
/**	This function is the main program entry point
 *	The LCD is initialized an a welcome message is printed. Then the rest of the peripherals are
 *	initialized and a measurent lasting 2 seconds are taken. The program then enters the main loop,
 *	first checking if the calibration button is pressed.\n If it is the maximal voltage measured at the
 *	A/D is used for calibrating the D/A reading to voltage scale factor #vin_cal.\n
 *	If not the program adjust the meauring time and print the values to the screen, and the loop starts
 *	over, forever...
 */
void main(void)
{
	//Used to save the frequency unit for the display
	const unsigned char		*unit;
	//The final calculated frequency
	unsigned long			scaled_freq;
	//The final Peak-to-Peak voltage
	fixed					v;

	vin_min.fixed = 0;
	vin_min.split.integer = UINT_MAX;
	vin_max.fixed = 0;
	vin_cal.fixed = 13421773; //204.80 using 16.16 fixed point;


	//All of port A are inputs, RA0 measures the voltage of the signal
	TRISA = 0xff;
	//All outputs fot the LCD, except RB4 where the calibrate button is connected
	TRISB = 0b00010000;
	//All outputs RC3-RC5 for the LCD, except RC1 where the pulses enters timer 1
	TRISC = 0b00000001;
	
	COUNT_OFF();

	//Initialize the LCD
	lcd_init();

	//Print a welcome screen
	printf("      Frequency\n");
	printf("       counter\n");
	printf("        V1.21\n");
	printf("     By deadbok\n");
	
	//Turn the cursor off
	lcd_cursor(0);

	//Init timer 0
	init_TMR0();
	//Init timer 1
    init_TMR1();
    //Init the ADC
	init_ADC();
	//Init the interrupt system
	init_int();

	//Take a measurement. 2 seconds is the longest measuring period theoreticly precise down to 1/2Hz
	measure(2000);
	//Clear the LCD
	lcd_clear();

	//Forever...
	for(;;)
	{
		//Clear the watchdog timer
		CLRWDT();

		//If the calibrate button is pressed
		if (RB4)
		{
			//Clear the LCD
			lcd_clear();

			//Calibration is expecting a sine wave of 1V RMS on the input
			//Set the calibration value to the one giving a readout of 1V RMS
			vin_cal = divfx_ul16(vin_max, SQRT2);
			
			//Wait 2 seconds
			DelayS(2);
			//Take a new reading
			measure(2000 / divisor);
		}

		//Move the cursor home
		lcd_home();

		//Calculate the frequencty
		scaled_freq = freq * divisor;

		//If input frequency is higher than 1000 switch to a sample time of 0.2S
		divisor = 1;
		if (scaled_freq > 1000)
			divisor = 10;

		//Decide whether to do the print our in Hz or kHz
		//Shift at 100000kHz.
		unit = "Hz\0";
		if (scaled_freq > 100000)
		{
			unit = "kHz\0";
			scaled_freq /= 1000;
		}
		//Print the frequency
		printf("FREQ: ");
		pad(6, scaled_freq, ' ');
		printf("%lu", scaled_freq);
		if ( freq < ( 100000 / divisor))
			printf(".000 %s\n", unit);
		else
		{
			scaled_freq = freq_fraction();
			printf(".%lu %s\n", scaled_freq , unit);
		}

		//Calculate the peak-to-peak voltage
		v.fixed = vin_max.fixed - vin_min.fixed;
		v = divfx16(v, vin_cal);

		//Print peak-to-peak voltage
		printf("Vpp:  ");
		printfx(v);
		printf(" V\n");
		
		//Print the RMS voltage
		v = divfx_ul16(v, SQRT2);
		printf("Vrms: ");
		printfx(v);
		printf(" V\n");
		
		//Reset maximum and minumum voltage
		vin_min.fixed = 0;
		vin_min.split.integer = UINT_MAX;
		vin_max.fixed = 0;

		//Do another measurement
		measure(2000 / divisor);
	}
}

