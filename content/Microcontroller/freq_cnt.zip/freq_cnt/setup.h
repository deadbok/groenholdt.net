#ifndef	SETUP_H
#define	SETUP_H

/**
 * Include file for general configuration definitions
 * \file setup.h
 * \author Martin Bo Kristensen Gr�nholdt
 */

/** The clock speed
 */
#define PIC_CLK 20000000 //20Mhz

#endif


