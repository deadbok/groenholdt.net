#ifndef FIXED_H
#define FIXED_H


struct fixed_split
{
	unsigned int	fraction;
	unsigned int	integer;
};	

typedef union
{
	unsigned long 			fixed;
	struct fixed_split		split;
} fixed;

#define mulfx16(x,y) (((y) >> 16) * (x))		// Multiply a fixed by a fixed
//#define divfx16(x,y) (((x) << 16) / (y))    		// Divide a fixed by a fixed
//#define printfx(x) printf("%lu.%lu", x >> 16, (unsigned long) ((((x) & 0b0000001111111111) * 100) >> 16))
#define multfixSlow(a,b) ((int)((((long)(a))*((long)(b)))>>8)) //multiply two fixed #don't use this-too slow:
#define divfixSlow(a,b)  ((int)((((long)(a))<<8)/((long)(b)))) //divide two fixed #:don't use this-too slow:

extern fixed divfx16(fixed source, fixed divisor);
extern fixed divfx_ul16(fixed source, unsigned long divisor);
extern void printfx(fixed val);

#endif
