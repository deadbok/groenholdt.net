#include <pic.h>
#include <stdio.h>
#include <limits.h>
#include "fixed.h"
#include "lcd.h"

fixed	divfx16(fixed source, fixed divisor)
{
	unsigned long	src_hi, src_lo;
	unsigned long	div_hi, div_lo;
	unsigned long	temp_hi, temp_lo;
	unsigned int	i = 0;
	unsigned long	j = 0;
	
	if ( !divisor.fixed )
		return(source);
	
	src_hi = (source.fixed & 0xFFFF0000) >> 16;
	src_lo = (source.fixed & 0x0000FFFF) << 16;
	
	source.fixed = 0;
	
	div_hi = temp_lo = temp_hi = 0;
	div_lo = divisor.fixed;
	
	while(src_hi > div_hi)
	{
		div_hi = (div_hi << 1) + ((div_lo & 0x80000000) >> 31);
		div_lo = div_lo << 1;
		i++;
	}

	div_lo = (div_lo >> 1) + ((div_hi & 0x000000001) << 31);
	div_hi = div_hi >> 1;
	
	for (; i > 1; i--)
	{
		j = 1;
		
		if ( div_hi	> src_hi )
			j = 0;
		else
		{
			temp_lo = src_lo;
			
			if ( src_hi > 0 )
			{
				src_lo -= div_lo;
			
				if ( src_lo > temp_lo)
					src_hi--;
				
				src_hi -= div_hi;
			}
			else
			{
				if ( src_lo < div_lo )
					j = 0;
				else
					src_lo -= div_lo;
			}
		}

		div_lo = (div_lo >> 1) + ((div_hi & 0x000000001) << 31);
		div_hi = div_hi >> 1;

		
		source.fixed += j << (i - 1);
	}
	
	return(source);
}

fixed	divfx_ul16(fixed source, unsigned long divisor)
{
	unsigned long	src_hi, src_lo;
	unsigned long	div_hi, div_lo;
	unsigned long	temp_hi, temp_lo;
	unsigned int	i = 0;
	unsigned long	j = 0;
	
	if ( !divisor )
		return(source);
	
	src_hi = (source.fixed & 0xFFFF0000) >> 16;
	src_lo = (source.fixed & 0x0000FFFF) << 16;
	
	source.fixed = 0;
	
	div_hi = temp_lo = temp_hi = 0;
	div_lo = divisor;
	
	for (; src_hi > div_hi; i++)
	{
		div_hi = (div_hi << 1) + ((div_lo & 0x80000000) >> 31);
		div_lo = div_lo << 1;
	}

	div_lo = (div_lo >> 1) + ((div_hi & 0x000000001) << 31);
	div_hi = div_hi >> 1;

	for (; i > 1; i--)
	{
		j = 1;
		
		if ( div_hi	> src_hi )
			j = 0;
		else
		{
			temp_lo = src_lo;
			
			if ( src_hi > 0 )
			{
				src_lo -= div_lo;
			
				if ( src_lo > temp_lo)
					src_hi--;
				if ( src_hi )
					src_hi -= div_hi;
			}
			else
			{
				if ( src_lo < div_lo )
					j = 0;
				else
					src_lo -= div_lo;
			}
		}

		div_lo = (div_lo >> 1) + ((div_hi & 0x000000001) << 31);
		div_hi = div_hi >> 1;

		
		source.fixed += j << (i - 1);
	}
	
	return(source);
}

void printfx(fixed val)
{
	unsigned int	fraction;
	
	pad(6, val.split.integer, ' ');
	printf("%u.", val.split.integer);
	
	fraction = ((unsigned long)(val.split.fraction) * 1000) >> 16;
	pad(3, fraction, '0');
	printf("%u", fraction);
}
	
