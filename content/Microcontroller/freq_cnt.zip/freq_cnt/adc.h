#ifndef ADC_H
#define ADC_H

/**
 * Include file for the ADC handling routines
 * \file adc.h
 * \author Martin Bo Kristensen Gr�nholdt
 */

extern void init_ADC(void);

#endif

