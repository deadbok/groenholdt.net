#include <pic.h>
#include "main.h"
#include "timer.h"

/** Contain the timer handling routines
 * 	\file timer.c
 * 	\author Martin Bo Kristensen Gr�nholdt
 */

/**	This function initializes timer 0 in the following way:
 *		- Instruction clock as source
 *		- Increment on low-to-high transition
 *		- Prescaler 1:8
 *
 *	With a prescaler og eight, and a crystal of 20MHz
 *	The timer will increase every:
 *
 *		1 / (20MHz / instruction cycles / prescaler) = 1 / (20000000 / 4 / 8) = 1.6us
 *
 *	So every 625 counts of timer 0 is a milisecond
 *
 *	Timer 0 is used to keep track of measuring times.
 */
void init_TMR0(void)
{
	//Set clock source
	T0CS = 0;
	//Set to increase at low-to-high transistion
	T0SE = 0;
	//Tie the prescaler to the timer
	PSA = 0;
	//Prescaler 1:8
	PS2 = 0;
	PS1 = 1;
	PS0 = 0;

	//Reset the timer register
	TMR0 = time = 0;
}

/** This function initializes timer 1 in the following way:
 *		- Prescaler of 1:2
 *		- The internal oscillator disabled
 *		- Timer 1 clock source is external
 *	Timer 1 is used to count the pulses during measurement.
 *	The 16 bit counter is extended by TMR1HH to 32 bit
 */
void init_TMR1(void)
{
	//Set the prescaler to 1:2
	T1CKPS1 = 0;
	T1CKPS0 = 1;
	//Oscillator disabled
	T1OSCEN = 0;
	//Clock source external
	TMR1CS	= 1;
	
	//Turn timer 1 on
	TMR1ON = 1;

	//Reset the timer register
	TMR1HH = TMR1H = TMR1L = 0;
}

