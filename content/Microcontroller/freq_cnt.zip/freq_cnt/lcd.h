#ifndef LCD_H
#define LCD_H

/**
 * Include file for the LCD routines
 * \file lcd.h
 * \author Martin Bo Kristensen Gr�nholdt
 */

extern void lcd_write(unsigned char);
extern void lcd_clear(void);
extern void lcd_home(void);
extern void puts(const char * s);
extern void lcd_init(void);
extern void putch(char);
extern void lcd_cursor(unsigned char enabled);
extern void pad(unsigned char precision, unsigned long value, unsigned char ch);


#endif
